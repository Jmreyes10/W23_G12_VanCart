package com.example.w23_g12_ecommerceapp;

public class DrawerItem {
    private String feature;
    private int iconId;

    public DrawerItem(String feature, int iconId) {
        this.feature = feature;
        this.iconId = iconId;
    }

    public String getFeature() {
        return feature;
    }
    public void setFeature(String feature) {
        this.feature = feature;
    }

    public int getIconId() {
        return iconId;
    }

    public void setIconId(int iconId) {
        this.iconId = iconId;
    }
}
